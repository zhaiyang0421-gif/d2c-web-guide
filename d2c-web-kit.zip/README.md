# 设计转代码 · 通用工具包

准备可分享的设计截图、目标文件和需要覆盖的状态。使用任务模板记录范围。打开 `example.html` 即可运行练习样例。

## 在 Codex 中复用

把 `.agents/skills/d2c-web-workflow/` 完整复制到目标项目的 `.agents/skills/`，然后在该项目打开 Codex。输入 `$d2c-web-workflow` 并附上截图、实现范围和预期交互。工作区已有技术栈时，沿用它的组件、样式和验证命令。

可直接将 [任务模板](task-template.md) 的内容作为实现提示词。
